CONTENTS OF THIS FILE
---------------------
 * Introduction
 * Requirements
 * Installation
 * Configuration
 * Maintainers

INTRODUCTION
------------
The Sharethis module provides social bookmarking utility on selected node types.

REQUIREMENTS
------------
This module requires none.

INSTALLATION
------------
 * Install as you would normally install a contributed Drupal module. See:
   https://www.drupal.org/documentation/install/modules-themes/modules-8
   for further information.

CONFIGURATION
-------------
 * Configure the Sharethis Module settings in
   Administration » Configuration » Services » Sharethis:

MAINTAINERS
-----------
Current maintainers:
 * Naveen Valecha (naveenvalecha) - https://drupal.org/u/naveenvalecha
 * Abhishek Anand (abhishek-anand) - https://www.drupal.org/u/abhishek-anand
